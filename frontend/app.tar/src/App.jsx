import React from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import LandingPage from "./pages/LandingPage";
import MapPage from "./pages/MapPage";
import DownloadPage from "./pages/DownloadPage";
import MyListPage from "./pages/MyListPage";
import "@fontsource/open-sans"; // Default weight (400)
import "@fontsource/open-sans/600.css"; // Semi-bold weight
import "@fontsource/open-sans/700.css"; // Bold weight

// 1) Import your components at the top
import Chatbot from "./components/Chatbot";
import Navbar from "./components/Navbar";

function AppContent() {
  const location = useLocation();

  return (
    <>
      {/* 2) Render the Navbar and Chatbot once at the top level */}
      <Navbar />
      <Chatbot />

      {/* Page transitions using Framer Motion */}
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route
            path="/"
            element={
              <motion.div
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -100 }}
                transition={{ duration: 0.2 }}
              >
                <LandingPage />
              </motion.div>
            }
          />
          <Route
            path="/download"
            element={
              <motion.div
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -100 }}
                transition={{ duration: 0.2 }}
              >
                <DownloadPage />
              </motion.div>
            }
          />
          <Route
            path="/map"
            element={
              <motion.div
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -100 }}
                transition={{ duration: 0.2 }}
              >
                <MapPage />
              </motion.div>
            }
          />
          <Route
            path="/my-list"
            element={
              <motion.div
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -100 }}
                transition={{ duration: 0.2 }}
              >
                <MyListPage />
              </motion.div>
            }
          />
        </Routes>
      </AnimatePresence>
    </>
  );
}

// Wrap the AppContent with the BrowserRouter
function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
