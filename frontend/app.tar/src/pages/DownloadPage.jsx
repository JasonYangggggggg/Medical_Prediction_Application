import React, { useState, useEffect } from "react";
import Hero from "../components/Hero";
import FeaturesSection from "../components/FeaturesSection";
import SearchBar from "../components/SearchBar";
import Navbar from "../components/Navbar";
import WelcomeModal from "../components/WelcomeModal";

import HeroDownload from "../components/HeroDownload";
import { FaLinux } from "react-icons/fa";
import { 
  Download, 
  ArrowRight, 
  CheckCircle, 
  Shield, 
  Zap, 
  Sparkles,
  Monitor,
  Smartphone,
  Laptop
} from 'lucide-react';
function DownloadPage() {
  const [productName, setProductName] = useState("");
    const [scraping, setScraping] = useState(false);
    const [isModalOpen, setModalOpen] = useState(false); // Control modal visibility
    


    const [installSoftwareModal, setInstallSoftwareModal] = useState(false);
    const [userZip, setUserZip] = useState(() => {
      // Load ZIP code from Local Storage
      return localStorage.getItem("userZip") || "";
    });
    const [softwareInstall, setSoftwareInstall] = useState(false);
  



     const [downloadingV1, setDownloadingV1] = useState(false);
  const [downloadingV2, setDownloadingV2] = useState(false);


    
    // Check for ZIP code on component mount
    useEffect(() => {
      if(!softwareInstall){
          setInstallSoftwareModal(true);
      }
      else if (!userZip) {
        setModalOpen(true); // Show modal if no ZIP code is set
      }
    }, [userZip, softwareInstall]);
  
    const scrapeFirstStores = () => {
      setScraping(true);
      setTimeout(() => setScraping(false), 2000); // Mock scraping function
    };
  
    const handleZipSubmit = (zip) => {
      setUserZip(zip); // Save ZIP to state
      localStorage.setItem("userZip", zip); // Save ZIP to Local Storage
      setModalOpen(false); // Close the modal
    };
  
    const openModal = () => {
      setModalOpen(true); // Allow manual opening of the modal
    };

    const handleV2Download = () => {
    
      alert("It is coming!");
  
    };
    const handleV1Download = () => {
    alert("V1 download!");
  
  };
  




  return (
   
   
   
<div className="flex">
      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <div className="flex-grow ml-20 min-h-screen bg-gray-100 text-gray-800 font-['Nunito']">
        {/* Hero Container */}
        <section className="relative w-full flex justify-center bg-white py-4 md:py-6 border-b border-gray-100">
          <div className="w-full max-w-6xl relative px-6">
            <HeroDownload />
          </div>
        </section>

        {/* Enhanced Features Section */}
        <section className="w-full flex justify-center bg-gray-100 py-12 md:py-16">
          <div className="w-full max-w-6xl space-y-12 px-6">
            
            {/* Key Benefits Section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
              <div className="bg-white rounded-2xl p-6 text-center shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Fast & Efficient</h3>
                <p className="text-gray-600">Optimized performance for seamless workflow</p>
              </div>
              <div className="bg-white rounded-2xl p-6 text-center shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Secure & Reliable</h3>
                <p className="text-gray-600">Enterprise-grade security you can trust</p>
              </div>
              <div className="bg-white rounded-2xl p-6 text-center shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Easy to Use</h3>
                <p className="text-gray-600">Intuitive interface designed for productivity</p>
              </div>
            </div>

            {/* Software V1 Enhanced */}
            <div className="bg-white rounded-3xl shadow-lg hover:shadow-xl transition-all duration-500 overflow-hidden border border-gray-200">
              <div className="flex flex-col lg:flex-row items-center">
                {/* Text Section */}
                <div className="flex-1 p-8 lg:p-12 space-y-6">
                  <div className="space-y-3">
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-50 text-green-700 rounded-full text-sm font-medium">
                      <CheckCircle className="w-4 h-4" />
                      Available Now
                    </div>
                    <h3 className="text-2xl lg:text-3xl font-bold text-black tracking-tight">
                      Software V1 (Version 1)
                    </h3>
                    <h2 className="text-xl lg:text-2xl text-gray-700 leading-relaxed">
                      Enable your software Now
                    </h2>
                  </div>
                  
                  {/* Enhanced Feature List */}
                  <div className="space-y-4">
                    <div className="flex items-start gap-3 text-gray-700">
                      <Shield className="w-5 h-5 text-blue-500 mt-0.5" />
                      <div>
                        <span className="font-medium">Enterprise Security</span>
                        <p className="text-sm text-gray-600">Bank-level encryption and secure data handling</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 text-gray-700">
                      <Zap className="w-5 h-5 text-yellow-500 mt-0.5" />
                      <div>
                        <span className="font-medium">Lightning Performance</span>
                        <p className="text-sm text-gray-600">Optimized for speed and efficiency</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 text-gray-700">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                      <div>
                        <span className="font-medium">Production Ready</span>
                        <p className="text-sm text-gray-600">Thoroughly tested and battle-proven</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-3">
                      {/* Primary Download Button - Windows */}
                      <a
  href="https://bargainbee.shahmu.com/downloads/BB%20Scraper%20Setup%201.0.0.exe"
  target="_blank"
  rel="noopener noreferrer"
  className="group/btn relative overflow-hidden inline-flex items-center justify-center gap-2.5 px-8 py-3.5 bg-black hover:bg-gray-900 rounded-xl text-white font-medium text-base transition-all duration-200 hover:scale-[1.02] disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none shadow-sm"
>
  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
    <path d="M0,12.4v5.9l6.8,0.9V13L0,12.4z M7.7,19.4l12.6,1.8V13H7.7V19.4z M20.3,11.1V3L7.7,4.8v6.3H20.3z M6.8,4.9L0,5.8v5.9 l6.8-0.4V4.9z"/>
  </svg>
  <span>Download for Windows</span>
  <svg className="w-4 h-4 opacity-60 group-hover/btn:translate-x-0.5 group-hover/btn:opacity-100 transition-all" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M7 17l9.2-9.2M17 17V7H7"/>
  </svg>
</a>

                      {/* Disabled Mac Button */}
                      <button
                        disabled={true}
                        className="relative overflow-hidden inline-flex items-center justify-center gap-2.5 px-8 py-3.5 bg-gray-100 border border-gray-200 rounded-xl text-gray-400 font-medium text-base cursor-not-allowed opacity-50"
                      >
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                        </svg>
                        <span>Download for Mac</span>
                        <span className="text-xs bg-gray-300 text-gray-600 px-2 py-0.5 rounded-full ml-1">Coming Soon</span>
                      </button>
                      <button
                        disabled={true}
                        className="relative overflow-hidden inline-flex items-center justify-center gap-2.5 px-8 py-3.5 bg-gray-100 border border-gray-200 rounded-xl text-gray-400 font-medium text-base cursor-not-allowed opacity-50"
                      >
                        <FaLinux className="w-4 h-4" />                   
                        <span>Download for Linux</span>
                        <span className="text-xs bg-gray-300 text-gray-600 px-2 py-0.5 rounded-full ml-1">Coming Soon</span>
                      </button>

                      {/* Tertiary Action */}
                      <div className="flex justify-center pt-2">
                        <button className="text-gray-600 hover:text-gray-900 text-sm font-medium transition-colors hover:underline decoration-1 underline-offset-2">
                          View system requirements
                        </button>
                      </div>

                    
                    </div>
                </div>

                {/* Enhanced Image Section */}
                <div className="flex-1 p-8 lg:p-12 flex justify-center">
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-500 rounded-2xl blur-lg opacity-20 scale-110 group-hover:opacity-30 transition-opacity"></div>
                    <div className="relative bg-white rounded-2xl p-4 shadow-lg">
                      <img
                        className="w-full h-auto rounded-xl"
                        src="https://via.placeholder.com/428x460/667eea/ffffff?text=Software+V1"
                        alt="Feature Illustration"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Software V2 Enhanced */}
            <div className="bg-white rounded-3xl shadow-lg hover:shadow-xl transition-all duration-500 overflow-hidden border border-gray-200 relative">
              {/* Coming Soon Badge Overlay */}
              <div className="absolute top-6 right-6 z-20">
                <div className="bg-orange-100 text-orange-600 px-4 py-2 rounded-full text-sm font-medium">
                  Coming Soon
                </div>
              </div>

              <div className="flex flex-col lg:flex-row-reverse items-center">
                {/* Text Section */}
                <div className="flex-1 p-8 lg:p-12 space-y-6">
                  <div className="space-y-3">
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-50 text-orange-600 rounded-full text-sm font-medium">
                      <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                      In Development
                    </div>
                    <h3 className="text-2xl lg:text-3xl font-bold text-black tracking-tight">
                      Software V2 (Version 2)
                    </h3>
                    <h2 className="text-xl lg:text-2xl text-gray-700 leading-relaxed">
                      Under Development.......
                    </h2>
                  </div>
                  
                  {/* Enhanced Feature List */}
                  <div className="space-y-4 opacity-75">
                    <div className="flex items-start gap-3 text-gray-700">
                      <Sparkles className="w-5 h-5 text-purple-500 mt-0.5" />
                      <div>
                        <span className="font-medium">AI-Powered Features</span>
                        <p className="text-sm text-gray-600">Next-generation automation and intelligence</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 text-gray-700">
                      <Zap className="w-5 h-5 text-blue-500 mt-0.5" />
                      <div>
                        <span className="font-medium">Enhanced Performance</span>
                        <p className="text-sm text-gray-600">50% faster processing with new architecture</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 text-gray-700">
                      <Shield className="w-5 h-5 text-green-500 mt-0.5" />
                      <div>
                        <span className="font-medium">Advanced Security</span>
                        <p className="text-sm text-gray-600">Zero-trust architecture and quantum encryption</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4">
                    
                    <button className="px-6 py-3 border border-gray-300 rounded-2xl text-gray-700 hover:bg-gray-50 transition-colors font-medium">
                      Get Notified
                    </button>
                  </div>
                </div>

                {/* Enhanced Image Section */}
                <div className="flex-1 p-8 lg:p-12 flex justify-center">
                  <div className="relative group opacity-75">
                    <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-pink-500 rounded-2xl blur-lg opacity-20 scale-110 group-hover:opacity-30 transition-opacity"></div>
                    <div className="relative bg-white rounded-2xl p-4 shadow-lg">
                      <img
                        className="w-full h-auto rounded-xl"
                        src="https://via.placeholder.com/428x460/764ba2/ffffff?text=Software+V2"
                        alt="Feature Illustration"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Additional CTA Section */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-3xl p-8 lg:p-12 text-center">
              <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">
                Need Help Getting Started?
              </h3>
              <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
                Our support team is here to help you make the most of our software solutions.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="px-8 py-3 bg-[#ffee33] hover:bg-[#ffe619] rounded-2xl text-[#333333] font-semibold transition-colors">
                  Contact Support
                </button>
                <button className="px-8 py-3 border border-gray-300 rounded-2xl text-gray-700 hover:bg-white transition-colors font-medium">
                  View Documentation
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Welcome Modal */}
        <WelcomeModal
          isOpen={isModalOpen}
          onClose={() => setModalOpen(false)}
          onSubmit={handleZipSubmit}
        />
      
      </div>
    </div>
  );
}

export default DownloadPage;
