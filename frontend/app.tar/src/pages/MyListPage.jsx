// src/pages/YourPageName.jsx
import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";          // ← still needed elsewhere


import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import { faDownload, faQrcode,faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';
import {
  faTrashAlt,
  faClone,
  faPlus,
  faChevronDown,
  faChevronUp,
  faSearch,
} from "@fortawesome/free-solid-svg-icons";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { v4 as uuidv4 } from "uuid";
import Navbar from "../components/Navbar";
import Hero from "../components/Hero";           // ← NEW import
import WelcomeModal from "../components/WelcomeModal";
import SoftwareInstall from "../components/SoftwareInstall";
import QRCode from 'qrcode';
import { scraperApi } from "../utils/api";

/*───────────────── constants ─────────────────*/
const POLL_MS = 800;
const POLL_TIMEOUT_MS = 35_000;
const PLACEHOLDER_IMG =
  "https://raw.githubusercontent.com/tailwindlabs/heroicons/074a8abd/optimized/outline/photo.svg";
const todayISO = () => new Date().toISOString().split("T")[0];

/* recognise Default List regardless of id */
const isDefaultBoard = (id, col) =>
  col.title === "Default List" || id.startsWith("default-");

/*───────────────── main component ─────────────────*/
export default function Kanban() {
  /* calendar filter */
  const [filterType, setFilterType] = useState("day"); // day | week | month | year
  const [selectedDate, setSelectedDate] = useState(todayISO);
  const [isModalOpen, setModalOpen] = useState(false); // Control modal visibility
    const [userZip, setUserZip] = useState(() => {
      // Load ZIP code from Local Storage
      return localStorage.getItem("userZip") || "";
    });
    const [softwareInstall, setSoftwareInstall] = useState(false);
    const [installSoftwareModal, setInstallSoftwareModal] = useState(false);

  /* board state */
  const [columns, setColumns] = useState(() => {
    const cached = JSON.parse(localStorage.getItem("kanbanColumns"));
    if (cached)
      return Object.fromEntries(
        Object.entries(cached).map(([id, col]) => [
          id,
          { ...col, date: col.date || todayISO() },
        ])
      );
    const id = "default-" + uuidv4();
    return {
      [id]: {
        title: "Default List",
        date: todayISO(),
        items: [],
        createdAt: new Date().toLocaleString(),
      },
    };
  });

  useEffect(() => {
    localStorage.setItem("kanbanColumns", JSON.stringify(columns));
  }, [columns]);
  useEffect(() => {
          if(!softwareInstall){
              setInstallSoftwareModal(true);
          }
          else if (!userZip) {
            setModalOpen(true); // Show modal if no ZIP code is set
          }
        }, [userZip, softwareInstall]);
  
  
  
    const handleZipSubmit = (zip) => {
      setUserZip(zip); // Save ZIP to state
      localStorage.setItem("userZip", zip); // Save ZIP to Local Storage
      setModalOpen(false); // Close the modal
    };
  
    const openModal = () => {
      setModalOpen(true); // Allow manual opening of the modal
    };

  /* edit-title state */
  const [editingId, setEditingId] = useState(null);
  const [newTitle, setNewTitle] = useState("");
  const [errorMsg, setErrorMsg] = useState(null);
  const inputRef = useRef(null);

  /* ── userList state so we can refresh it after hydration ── */        // 🟢
  const [userList, setUserList] = useState(() =>                       // 🟢
    JSON.parse(localStorage.getItem("userList") || "[]")               // 🟢
  );                                                                   // 🟢

  /* ── one-shot location hydration (inside the component!) ── */       // 🟢
  useEffect(() => {                                                     // 🟢
    (async () => {                                                      // 🟢
      const updated = await hydrateMissingLocations(userZip);           // 🟢
      setUserList(updated);                                            // 🟢
    })();                                                               // 🟢
  }, []);                                                               // 🟢

  /*───────────────── helper ─────────────────*/
  const mutateItems = (bid, fn) =>
    setColumns((prev) => ({
      ...prev,
      [bid]: { ...prev[bid], items: fn(prev[bid].items) },
    }));

  /*───────────────── board CRUD ─────────────────*/
  const handleDeleteBoard = (bid) =>
    setColumns((prev) => {
      if (isDefaultBoard(bid, prev[bid])) {
        alert("You cannot delete the Default List.");
        return prev;
      }
      const { [bid]: _removed, ...rest } = prev;
      if (editingId === bid) setEditingId(null);
      return rest;
    });

  const addBoard = () =>
    setColumns((prev) => {
      const id = uuidv4();
      let n = 1;
      while (
        Object.values(prev).some(
          (c) => c.date === selectedDate && c.title === `List (${n})`
        )
      )
        n += 1;
      return {
        ...prev,
        [id]: {
          title: `List (${n})`,
          date: selectedDate,
          items: [],
          createdAt: new Date().toLocaleString(),
        },
      };
    });

  const renameBoard = (bid) =>
    setColumns((prev) => {
      const dupe = Object.values(prev).some(
        (c) => c.date === prev[bid].date && c.title === newTitle
      );
      if (dupe) {
        // setErrorMsg("Duplicate name on that date.");
        return prev;
      }
      setErrorMsg(null);
      return {
        ...prev,
        [bid]: { ...prev[bid], title: newTitle },
      };
    });

  /*───────────────── similar products ─────────────────*/
  const [similarState, setSimilarState] = useState({
    status: "idle",
    items: [],
  });
  const [carouselCollapsed, setCarouselCollapsed] = useState(true);

  const fetchSimilar = async (query) => {
    setCarouselCollapsed(false);
    setSimilarState({ status: "waiting", items: [] });

    try {
      // Trigger the scraping
      await scraperApi.scrapeDeals(query);
      
      // Poll for results from results.json
      const start = Date.now();
      (function poll() {
        scraperApi.getResults()
          .then((d) => {
            // Check both query and originalQuery for matches
            const queryMatch = d && (
              d.query?.toLowerCase() === query.toLowerCase() ||
              d.originalQuery?.toLowerCase() === query.toLowerCase()
            );
            if (queryMatch) {
              setSimilarState({ status: "done", items: d.items || [] });
            } else if (Date.now() - start < POLL_TIMEOUT_MS)
              setTimeout(poll, POLL_MS);
            else setSimilarState({ status: "error", items: [] });
          })
          .catch((error) => {
            console.log("MyList poll error:", error);
            if (Date.now() - start < POLL_TIMEOUT_MS)
              setTimeout(poll, POLL_MS);
            else setSimilarState({ status: "error", items: [] });
          });
      })();
    } catch (error) {
      console.error("Search failed:", error);
      setSimilarState({ status: "error", items: [] });
    }
  };

  const addFromCarousel = (prod) =>
    setColumns((prev) => {
      const [id, col] =
        Object.entries(prev).find(([bid, c]) => isDefaultBoard(bid, c)) ||
        Object.entries(prev)[0];
      return {
        ...prev,
        [id]: { ...col, items: [...col.items, { ...prod, expanded: false }] },
      };
    });

  /*───────────────── date comparison helpers ─────────────────*/
  const sameWeek = (d1, d2) => {
    const a = new Date(d1),
      b = new Date(d2);
    const weekNo = (d) => {
      d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
      d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
      const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
      return Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
    };
    return (
      a.getUTCFullYear() === b.getUTCFullYear() && weekNo(a) === weekNo(b)
    );
  };
  const sameMonth = (d1, d2) =>
    new Date(d1).getUTCFullYear() === new Date(d2).getUTCFullYear() &&
    new Date(d1).getUTCMonth() === new Date(d2).getUTCMonth();
  const sameYear = (d1, d2) =>
    new Date(d1).getUTCFullYear() === new Date(d2).getUTCFullYear();

  /* visible boards */
  const visibleBoards = Object.entries(columns).filter(([id, col]) => {
    if (isDefaultBoard(id, col)) return true;
    if (filterType === "day") return col.date === selectedDate;
    if (filterType === "week") return sameWeek(col.date, selectedDate);
    if (filterType === "month") return sameMonth(col.date, selectedDate);
    if (filterType === "year") return sameYear(col.date, selectedDate);
    return true;
  });

  /*───────────────── UI helpers ─────────────────*/

    const IconBtn = ({ icon, color, onClick }) => (
    <button
      onClick={onClick}
      className={`w-8 h-8 flex items-center justify-center rounded-full ${color} text-white shadow-md hover:shadow-lg transform hover:scale-110 active:scale-95 transition-all duration-200 backdrop-blur-sm`}
    >
      <FontAwesomeIcon icon={icon} size="xs" />
    </button>
  );

  const Card = ({ it, bid, idx }) => {
    const location = useItemLocation(it);

    return (
      <div className="group relative bg-white/95 backdrop-blur-sm border border-gray-200/60 rounded-2xl shadow-sm hover:shadow-xl hover:border-gray-300/80 transition-all duration-300 transform hover:-translate-y-1">
        {/* Enhanced card content layout with proper spacing */}
        <div className="p-5">
          {/* Header with title and action buttons */}
          <div className="flex items-start justify-between gap-3 mb-4">
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-gray-800 text-sm leading-relaxed group-hover:text-gray-900 transition-colors duration-200 line-clamp-2">
                {it.title}
              </p>
            </div>
            
            {/* Action buttons - always visible but subtle, more prominent on hover */}
            <div className="flex gap-1.5 opacity-60 group-hover:opacity-100 transition-all duration-300 flex-shrink-0">
              <IconBtn
                icon={faSearch}
                color="bg-green-500 hover:bg-green-600"
                onClick={() => fetchSimilar(it.title)}
              />
              <IconBtn
                icon={faClone}
                color="bg-blue-500 hover:bg-blue-600"
                onClick={() =>
                  mutateItems(bid, (its) => [
                    ...its,
                    { ...it, title: it.title },
                  ])
                }
              />
              <IconBtn
                icon={faMapMarkerAlt}
                color="bg-purple-500 hover:bg-purple-600"
                onClick={() => {
                  if (location === undefined) {
                    alert("Looking up location, please wait a moment and try again.");
                    return;
                  }
                  if (location && Array.isArray(location) && location.length === 2) {
                    const [lat, lng] = location;
                    window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
                  } else {
                    // Search for store address instead of product name
                    const storeQuery = it.store; // Use store name directly
                    const userZipCode = localStorage.getItem("userZip") || "";
                    
                    if (storeQuery) {
                      const searchQuery = userZipCode ? 
                        `${storeQuery} near ${userZipCode}` : 
                        storeQuery;
                      window.open(`https://www.google.com/maps/search/${encodeURIComponent(searchQuery)}`, '_blank');
                    } else {
                      alert("Store information not found.");
                    }
                  }
                }}
              />
              <IconBtn
                icon={faTrashAlt}
                color="bg-red-500 hover:bg-red-600"
                onClick={() =>
                  mutateItems(bid, (its) => its.filter((_, i) => i !== idx))
                }
              />
            </div>
          </div>
          
          {/* Content section with image and price */}
          <div className="flex gap-4 items-center">
            <div className="relative overflow-hidden rounded-xl shadow-sm flex-shrink-0">
              <img
                src={it.image || it.imgUrl || PLACEHOLDER_IMG}
                alt=""
                className="w-20 h-20 object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/5 group-hover:bg-black/0 transition-colors duration-300"></div>
            </div>
            
            <div className="flex-1 flex items-center">
              <p className="text-green-600 font-bold text-lg bg-green-50 px-4 py-2 rounded-xl inline-block shadow-sm">
                {it.price}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // 1. Download board data as readable text file


  const downloadBoardData = (boardId, boardData) => {
  let textContent = `${boardData.title}\n`;
  textContent += `${'='.repeat(boardData.title.length)}\n\n`;
  
  if (boardData.items && boardData.items.length > 0) {
    boardData.items.forEach((item, index) => {
      textContent += `${index + 1}. `;
      
      // Add item name/title
      if (item.name || item.title) {
        textContent += `${item.name || item.title}`;
      } else {
        textContent += `Unnamed Item`;
      }
      
      // Add store if available
      if (item.store) {
        textContent += ` (from ${item.store})`;
      }
      
      // Add price if available
      if (item.price) {
        textContent += ` - ${item.price}`;
      }
      
      textContent += '\n';
      
      // Add description if available
      if (item.description) {
        textContent += `   Description: ${item.description}\n`;
      }
      
      // Add location if available (assuming it.location is [latitude, longitude])
      if (item.location && Array.isArray(item.location) && item.location.length === 2) {
        const [lat, lng] = item.location;
        textContent += `   Google Maps Coordinates: https://www.google.com/maps?q=${lat},${lng}\n`;
      }
      
      textContent += '\n';
    });
  } else {
    textContent += 'No items in this board.\n';
  }
  
  textContent += `\nExported on: ${new Date().toLocaleString()}\n`;
  
  const dataBlob = new Blob([textContent], { type: 'text/plain' });
  
  const url = URL.createObjectURL(dataBlob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${boardData.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_board.txt`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
// 2. Generate QR Code with board data (formatted as readable text)


// Generate Map QR Code
// Generate Map QR Code
const generateMapQR = async (boardId, boardData) => {
  try {
    // Collect all valid locations
    const locations = boardData.items
      .filter(item => item.location && Array.isArray(item.location) && item.location.length === 2)
      .map(item => item.location);

    if (locations.length === 0) {
      alert('No items with valid locations found!');
      return;
    }

    let mapUrl;
    if (locations.length === 1) {
      // Single location - simple map
      const [lat, lng] = locations[0];
      mapUrl = `https://www.google.com/maps?q=${lat},${lng}`;
    } else {
      // Multiple locations - create a route/directions map
      const locationStrings = locations.map(([lat, lng]) => `${lat},${lng}`);
      mapUrl = `https://www.google.com/maps/dir/${locationStrings.join('/')}`;
    }

    const qrCodeDataURL = await QRCode.toDataURL(mapUrl, {
      errorCorrectionLevel: 'M',
      type: 'image/png',
      quality: 0.92,
      margin: 1,
      width: 300, // Larger size
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });

    return { qrCodeDataURL, locationCount: locations.length };
    
  } catch (error) {
    console.error('Error generating map QR code:', error);
    throw error;
  }

};

// Generate Text Download QR Code (includes ALL information) - ROBUST VERSION
const generateTextDownloadQR = async (boardId, boardData) => {
  try {
    // Always ensure we have some content, even if items are empty
    let fullContent = `${boardData.title || 'Untitled Board'}\n`;
    fullContent += `================\n\n`;
    
    if (boardData.items && boardData.items.length > 0) {
      fullContent += `Items (${boardData.items.length} total):\n\n`;
      
      // Show ALL items with complete details but limit length for QR compatibility
      boardData.items.forEach((item, index) => {
        const name = (item.name || item.title || 'Item').substring(0, 50); // Limit name length
        const price = item.price ? ` - ${item.price}` : '';
        const store = item.store ? ` (${item.store})` : '';
        
        fullContent += `${index + 1}. ${name}${price}${store}\n`;
        
        // Add location if available but keep it short
        if (item.location && Array.isArray(item.location) && item.location.length === 2) {
          fullContent += `   📍 ${item.location[0].toFixed(4)},${item.location[1].toFixed(4)}\n`;
        }
        fullContent += `\n`;
      });
    } else {
      fullContent += 'Board created but no items added yet.\n\n';
    }
    
    fullContent += `Generated: ${new Date().toLocaleDateString()}`;

    // Try different QR settings for better compatibility
    const qrSettings = [
      { errorCorrectionLevel: 'L', width: 400 },
      { errorCorrectionLevel: 'M', width: 350 },
      { errorCorrectionLevel: 'H', width: 300 }
    ];

    let qrCodeDataURL = null;
    let lastError = null;

    // Try each setting until one works
    for (const settings of qrSettings) {
      try {
        qrCodeDataURL = await QRCode.toDataURL(fullContent, {
          errorCorrectionLevel: settings.errorCorrectionLevel,
          type: 'image/png',
          quality: 0.92,
          margin: 1,
          width: settings.width,
          color: {
            dark: '#000000',
            light: '#FFFFFF'
          }
        });
        break; // Success, exit loop
      } catch (err) {
        lastError = err;
        // If content is too long, try shortened version
        if (fullContent.length > 500) {
          fullContent = `${boardData.title}\n================\n${boardData.items?.length || 0} items\nGenerated: ${new Date().toLocaleDateString()}`;
        }
      }
    }

    // Final fallback - create minimal QR if all else fails
    if (!qrCodeDataURL) {
      const minimalContent = `${boardData.title} - ${boardData.items?.length || 0} items`;
      qrCodeDataURL = await QRCode.toDataURL(minimalContent, {
        errorCorrectionLevel: 'L',
        width: 250,
        margin: 2
      });
    }

    const filename = `${(boardData.title || 'board').replace(/[^a-z0-9]/gi, '_').toLowerCase()}_board.txt`;
    return { qrCodeDataURL, filename, fullContent };
    
  } catch (error) {
    console.error('Error generating text download QR code:', error);
    
    // Emergency fallback - create simple QR with just board title
    try {
      const emergencyContent = boardData.title || 'BargainBee Board';
      const qrCodeDataURL = await QRCode.toDataURL(emergencyContent, {
        errorCorrectionLevel: 'L',
        width: 200,
        margin: 3
      });
      return { 
        qrCodeDataURL, 
        filename: 'board.txt', 
        fullContent: emergencyContent + ' (simplified due to error)'
      };
    } catch (finalError) {
      console.error('Final QR generation failed:', finalError);
      throw new Error('Unable to generate QR code');
    }
  }
};

// Main function to generate both QR codes - ROBUST VERSION
const generateDualQRCodes = async (boardId, boardData) => {
  try {
    // Always generate text QR - this should never fail now
    let textQR = null;
    try {
      textQR = await generateTextDownloadQR(boardId, boardData);
    } catch (error) {
      console.error('Text QR failed, using emergency fallback:', error);
      // Create absolute minimal QR as last resort
      const emergencyQR = await QRCode.toDataURL(`Board: ${boardData.title}`, {
        errorCorrectionLevel: 'L',
        width: 150
      });
      textQR = {
        qrCodeDataURL: emergencyQR,
        filename: 'board_emergency.txt',
        fullContent: `Emergency backup for: ${boardData.title}`
      };
    }

    // Check if any items have locations for map QR
    const hasLocations = boardData.items && boardData.items.some(item => 
      item.location && Array.isArray(item.location) && item.location.length === 2
    );

    // Generate map QR (only if locations exist)
    let mapQR = null;
    if (hasLocations) {
      try {
        mapQR = await generateMapQR(boardId, boardData);
      } catch (error) {
        console.warn('Map QR generation failed, continuing with text QR only:', error);
        // Don't fail the whole process if map QR fails
      }
    }

    // Show QR codes - text QR should always be available now
    showDualQRModal(boardData.title, mapQR, textQR);
    
  } catch (error) {
    console.error('Critical error in QR generation:', error);
    alert('QR code generation failed. Please try again or contact support.');
  }
};

// Modal to display both QR codes - ROBUST VERSION
const showDualQRModal = (boardTitle, mapQR, textQR) => {
  // Ensure we always have a text QR to show
  if (!textQR || !textQR.qrCodeDataURL) {
    console.error('No text QR available - this should not happen');
    alert('Unable to generate QR codes. Please try again.');
    return;
  }

  const modal = document.createElement('div');
  modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4';
  
  let mapSection = '';
  if (mapQR && mapQR.qrCodeDataURL) {
    mapSection = `
      <div class="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl shadow-lg border border-blue-200 transition-all hover:shadow-xl">
        <div class="text-center mb-4">
          <div class="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
            </svg>
          </div>
          <h4 class="font-bold text-lg text-blue-900 mb-2">Map View</h4>
        </div>
        <div class="text-center mb-4">
          <img src="${mapQR.qrCodeDataURL}" alt="Map QR Code" class="mx-auto w-60 h-60 rounded-lg shadow-md border-2 border-white" />
        </div>
        <div class="bg-white bg-opacity-70 rounded-lg p-3 text-center">
          <p class="text-sm font-medium text-blue-900">
            📍 ${mapQR.locationCount} Location${mapQR.locationCount > 1 ? 's' : ''}
          </p>
          <p class="text-xs text-blue-700 mt-1">
            Opens directly in Google Maps
          </p>
        </div>
      </div>
    `;
  } else {
    // Show placeholder if no map available
    mapSection = `
      <div class="bg-gradient-to-br from-gray-50 to-gray-100 p-6 rounded-xl shadow-lg border border-gray-200 opacity-50">
        <div class="text-center mb-4">
          <div class="w-12 h-12 bg-gray-400 rounded-full flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
            </svg>
          </div>
          <h4 class="font-bold text-lg text-gray-600 mb-2">Map View</h4>
        </div>
        <div class="text-center mb-4">
          <div class="w-60 h-60 rounded-lg shadow-md border-2 border-gray-300 flex items-center justify-center mx-auto bg-gray-100">
            <span class="text-gray-500 text-sm">No locations available</span>
          </div>
        </div>
        <div class="bg-white bg-opacity-70 rounded-lg p-3 text-center">
          <p class="text-sm font-medium text-gray-600">
            📍 No locations found
          </p>
          <p class="text-xs text-gray-500 mt-1">
            Add items with store locations
          </p>
        </div>
      </div>
    `;
  }
  
  modal.innerHTML = `
    <div class="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
      <!-- Header -->
      <div class="bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-4 text-white">
        <div class="flex items-center justify-between">
          <h3 class="text-xl font-bold truncate">Share "${boardTitle}"</h3>
          <button onclick="this.closest('.fixed').remove()" 
                  class="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        </div>
        <p class="text-indigo-100 text-sm mt-1">Choose how you want to share your board</p>
      </div>

      <!-- Content -->
      <div class="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
        <div class="grid md:grid-cols-2 gap-6">
          ${mapSection}
          
          <div class="bg-gradient-to-br from-emerald-50 to-emerald-100 p-6 rounded-xl shadow-lg border border-emerald-200 transition-all hover:shadow-xl">
            <div class="text-center mb-4">
              <div class="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
              </div>
              <h4 class="font-bold text-lg text-emerald-900 mb-2">Complete Details</h4>
            </div>
            <div class="text-center mb-4">
              <img src="${textQR.qrCodeDataURL}" alt="Full Board Details QR Code" class="mx-auto w-60 h-60 rounded-lg shadow-md border-2 border-white" />
            </div>
            <div class="bg-white bg-opacity-70 rounded-lg p-3 text-center">
              <p class="text-sm font-medium text-emerald-900">
                📋 Full Board Information
              </p>
              <p class="text-xs text-emerald-700 mt-1">
                Items, prices, stores & details
              </p>
            </div>
          </div>
        </div>

        <!-- Instructions -->
        <div class="mt-6 bg-gray-50 rounded-xl p-4 border border-gray-200">
          <div class="flex items-start space-x-3">
            <div class="w-6 h-6 bg-amber-400 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <svg class="w-4 h-4 text-amber-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
              </svg>
            </div>
            <div>
              <h5 class="font-semibold text-gray-900 text-sm mb-1">How to use:</h5>
              <ul class="text-xs text-gray-600 space-y-1">
                <li>• <strong>Map View:</strong> Quick access to store locations (when available)</li>
                <li>• <strong>Complete Details:</strong> Full board with all item information</li>
                <li>• Point your camera at the QR code to scan</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.remove();
    }
  });
};

// Replace your existing generateQRCode function with this:
const generateQRCode = generateDualQRCodes;


// Helper to get/set cached locations in localStorage
function getCachedLocation(store) {          // cache by STORE
   const cache = JSON.parse(localStorage.getItem("locationCache") || "{}");
  return cache[store];
}
function setCachedLocation(store, location) {
   const cache = JSON.parse(localStorage.getItem("locationCache") || "{}");
  cache[store] = location;
   localStorage.setItem("locationCache", JSON.stringify(cache));
 }

// Helper to get locations from mapCache
function getMapCacheLocation(store) {
  const mapCache = JSON.parse(localStorage.getItem("mapCache") || "{}");
  const storeLocations = mapCache[store];
  
  if (storeLocations && Array.isArray(storeLocations) && storeLocations.length > 0) {
    // Return the first location as [lat, lng]
    const firstLocation = storeLocations[0];
    if (firstLocation.lat !== undefined && firstLocation.lon !== undefined) {
      return [Number(firstLocation.lat), Number(firstLocation.lon)];
    }
  }
  return null;
}
 
 // Custom hook to resolve and cache location for an item
 function useItemLocation(item) {
   const [location, setLocation] = useState(item.location);

   useEffect(() => {
     if (location && Array.isArray(location) && location.length === 2) return;

    const store = item.store?.trim();        // ← 🟢 use STORE
    if (!store) return;                      //    quit if we don't know it

    // 1. Check localStorage cache
    const cached = getCachedLocation(store);
    if (cached && Array.isArray(cached) && cached.length === 2) {
      setLocation(cached);
      item.location = cached; // update in-memory for QR, etc.
      return;
    }

    // 2. Check mapCache before making API call
    const mapCacheLocation = getMapCacheLocation(store);
    if (mapCacheLocation) {
      setLocation(mapCacheLocation);
      setCachedLocation(store, mapCacheLocation); // Cache it for future use
      item.location = mapCacheLocation; // update in-memory for QR, etc.
      return;
    }

    // 3. Fetch from map API — ask for branches near the user's ZIP if we have it
    fetch(
      "http://localhost:3334/map?" +
        new URLSearchParams({
          query: `${store} near ${localStorage.getItem("userZip") || "me"}`
        })
    )
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        // Take the first hit (or adapt if you prefer the full array)
        const res = data.results?.[0];
        if (
          res?.coordinates?.latitude !== undefined &&
          res?.coordinates?.longitude !== undefined
         ) {
          const loc = [Number(res.coordinates.latitude), Number(res.coordinates.longitude)];
           setLocation(loc);
          setCachedLocation(store, loc);
           item.location = loc; // update in-memory for QR, etc.
         }
       })
       .catch(() => {});
   }, [item, location]);

   return location;
}

  /*───────────────── render ─────────────────*/
  return (
  



  <>
      <Navbar />

      
      <div className="ml-20 min-h-screen bg-gradient-to-br from-gray-50/50 to-white">
       
        <div className="px-8 py-8 pb-[420px]"> 
          
          <div className="mb-12">
            <Hero />
          </div>

         
          <div className="bg-white/80 backdrop-blur-xl border border-gray-200/50 rounded-3xl p-8 mb-10 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex flex-wrap gap-6 items-center">
              <div className="flex items-center gap-6">
                
                <div className="relative">
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    className="appearance-none bg-white/90 backdrop-blur-sm border border-gray-300/60 rounded-2xl px-6 py-3 pr-12 text-sm font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500/60 hover:border-gray-400/80 transition-all duration-200 shadow-sm cursor-pointer"
                  >
                    <option value="day">Day</option>
                    <option value="week">Week</option>
                    <option value="month">Month</option>
                    <option value="year">Year</option>
                  </select>
                  <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none">
                    <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </div>
                
               
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="bg-white/90 backdrop-blur-sm border border-gray-300/60 rounded-2xl px-6 py-3 text-sm font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500/60 hover:border-gray-400/80 transition-all duration-200 shadow-sm"
                />
              </div>
              
              
              <button
                onClick={addBoard}
                className="ml-auto group relative inline-flex items-center justify-center w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 active:scale-95 overflow-hidden"
              >
                <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <FontAwesomeIcon icon={faPlus} className="text-white text-lg relative z-10" />
              </button>
            </div>
          </div>

          
          {errorMsg && (
            <div className="bg-gradient-to-r from-red-50 to-red-50/80 border border-red-200/80 rounded-2xl p-6 mb-8 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <p className="text-red-700 text-sm font-semibold">{errorMsg}</p>
              </div>
            </div>
          )}

          
          <div className="mb-8">
            <DragDropContext
              onDragEnd={({ source, destination }) => {
                if (!destination) return;
                setColumns((prev) => {
                  const srcItems = [...prev[source.droppableId].items];
                  const [moved] = srcItems.splice(source.index, 1);
                  if (source.droppableId === destination.droppableId) {
                    srcItems.splice(destination.index, 0, moved);
                    return {
                      ...prev,
                      [source.droppableId]: {
                        ...prev[source.droppableId],
                        items: srcItems,
                      },
                    };
                  }
                  const dstItems = [...prev[destination.droppableId].items];
                  dstItems.splice(destination.index, 0, moved);
                  return {
                    ...prev,
                    [source.droppableId]: {
                      ...prev[source.droppableId],
                      items: srcItems,
                    },
                    [destination.droppableId]: {
                      ...prev[destination.droppableId],
                      items: dstItems,
                    },
                  };
                });
              }}
            >
              <div
                className="grid gap-8"
                style={{ gridTemplateColumns: "repeat(auto-fill,minmax(360px,1fr))" }}
              >
 
            {visibleBoards.map(([bid, col]) => (
              <Droppable key={bid} droppableId={bid}>
                {(prov) => (
                  <div
                    ref={prov.innerRef}
                    {...prov.droppableProps}
                    className="border rounded-lg shadow p-4 relative bg-white max-h-[500px] overflow-y-auto"
                  >
                    
                    {editingId === bid ? (
                      <inpu
                        ref={inputRef}
                        value={newTitle}
                        onChange={(e) => setNewTitle(e.target.value)}
                        onBlur={() => renameBoard(bid)}
                        onKeyDown={(e) => e.key === "Enter" && renameBoard(bid)}
                        className="text-xl font-semibold w-full border-b mb-4"
                        autoFocus
                      />
                    ) : (
                      <h2
                        className="text-xl font-semibold mb-4 cursor-pointer"
                        onClick={() => {
                          setEditingId(bid);
                          setNewTitle(col.title);
                        }}
                      >
                        {col.title}
                      </h2>
                    )}

                    {col.items.map((it, idx) => (
                      <Draggable
                        key={bid + idx}
                        draggableId={bid + idx}
                        index={idx}
                      >
                        {(p) => (
                          <div
                            ref={p.innerRef}
                            {...p.draggableProps}
                            {...p.dragHandleProps}
                            className="mb-4"
                          >
                            <Card it={it} bid={bid} idx={idx} />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {prov.placeholder}

                    {/* Action buttons container */}
                    <div className="absolute top-2 right-2 flex gap-2">
                      {/* Download button */}
                      <button
                        onClick={() => downloadBoardData(bid, col)}
                        className="text-blue-500 hover:text-blue-700 transition-colors"
                        title="Download board data"
                      >
                        <FontAwesomeIcon icon={faDownload} />
                      </button>
                      
                      {/* QR Code button */}
                      <button
                        onClick={() => generateQRCode(bid, col)}
                        className="text-green-500 hover:text-green-700 transition-colors"
                        title="Generate QR Code"
                      >
                        <FontAwesomeIcon icon={faQrcode} />
                      </button>
                      
                      {/* Delete button (only for non-default boards) */}
                      {!isDefaultBoard(bid, col) && (
                        <button
                          onClick={() => handleDeleteBoard(bid)}
                          className="text-gray-500 hover:text-red-500 transition-colors"
                          title="Delete board"
                        >
                          <FontAwesomeIcon icon={faTrashAlt} />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </Droppable>
            ))}
              </div>
            </DragDropContext>
          </div>
        </div>


        <div className="fixed bottom-0 left-0 right-0 z-50 border-t border-gray-200/50">
          <div
            className={`transition-all duration-700 ease-in-out ${
              carouselCollapsed ? "h-16" : "h-96" // Increased height for better visibility
            }`}
          >
            
            <div className="absolute inset-0 bg-gradient-to-t from-white via-white/98 to-white/95 backdrop-blur-2xl shadow-2xl"></div>
            
            
            <div
              className="relative z-10 flex justify-between items-center px-8 py-4 cursor-pointer group hover:bg-gradient-to-r hover:from-gray-50/50 hover:to-transparent transition-all duration-300 border-b border-gray-100/50"
              onClick={() => setCarouselCollapsed((c) => !c)}
            >
              <div className="flex items-center gap-4">
                
                <div className={`w-1 h-6 bg-gradient-to-b from-yellow-400 to-yellow-600 rounded-full transition-all duration-500 ${!carouselCollapsed ? 'scale-y-150 shadow-lg shadow-yellow-400/30' : ''}`}></div>
                
               
                <div className="flex items-center gap-3">
                  <span className="font-bold text-lg text-gray-800 group-hover:text-gray-900 transition-colors duration-200">
                    {carouselCollapsed ? "Discover Similar Products" : "Similar Products"}
                  </span>
                  {similarState.status === "done" && (
                    <span className="px-3 py-1 bg-gradient-to-r from-yellow-100 to-yellow-50 text-yellow-700 text-xs font-bold rounded-full border border-yellow-200/50">
                      {similarState.items.length} found
                    </span>
                  )}
                </div>
              </div>
              
              
              <div className="flex items-center gap-3">
                {!carouselCollapsed && similarState.status === "done" && (
                  <span className="text-xs text-gray-500 font-medium animate-fade-in">
                    Scroll horizontally to explore →
                  </span>
                )}
                <div className="w-10 h-10 flex items-center justify-center bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm hover:shadow-md hover:bg-white/90 transition-all duration-300 group-hover:scale-105 border border-gray-200/60">
                  <FontAwesomeIcon
                    icon={carouselCollapsed ? faChevronUp : faChevronDown}
                    className="text-gray-600 text-sm transition-all duration-500 group-hover:text-gray-800"
                  />
                </div>
              </div>
            </div>
            
            
            {!carouselCollapsed && (
              <div className="relative z-10 h-full overflow-hidden">
                <div className="px-8 py-6" style={{ height: 'calc(100% - 64px)' }}>
                 
                  {similarState.status === "waiting" && (
                    <div className="flex items-center justify-center h-full">
                      <div className="flex flex-col items-center gap-6">
                       
                        <div className="relative">
                          <div className="w-16 h-16 border-4 border-gray-200 rounded-full"></div>
                          <div className="absolute top-0 left-0 w-16 h-16 border-4 border-t-yellow-500 border-r-yellow-400 border-b-transparent border-l-transparent rounded-full animate-spin"></div>
                        </div>
                        <div className="text-center">
                          <p className="text-gray-700 font-semibold mb-1">Discovering Similar Products</p>
                          <p className="text-gray-500 text-sm">Using advanced matching algorithms...</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  
                  {similarState.status === "error" && (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center bg-gradient-to-br from-red-50 to-red-50/50 border border-red-200/60 rounded-3xl p-8 max-w-md backdrop-blur-sm">
                        <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                          <svg className="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <p className="text-red-700 font-semibold mb-2">Unable to Load Similar Products</p>
                        <p className="text-red-600 text-sm">Please try again later or check your connection</p>
                      </div>
                    </div>
                  )}
                  
                 
                  {similarState.status === "done" && (
                    <div className="h-full relative">
                      <div 
                        className="horizontal-scroll-container overflow-x-auto overflow-y-hidden h-full"
                        style={{ 
                          height: '280px', // Fixed height to ensure products are fully visible
                          paddingBottom: '16px'
                        }}
                      >
                        <div 
                          className="flex gap-6 h-full items-start"
                          style={{ 
                            width: `${similarState.items.length * 300 + (similarState.items.length - 1) * 24 + 64}px`,
                            minWidth: '100%'
                          }}
                        >
                          {similarState.items.map((s, i) => (
                            <div
                              key={i}
                              className="w-72 flex-shrink-0 snap-start group"
                            >
                              
                              <div className="bg-white/95 backdrop-blur-xl border border-gray-200/60 rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-1 hover:scale-[1.02] p-5 h-64 flex flex-col">
                               
                                <div className="relative overflow-hidden rounded-2xl mb-4 bg-gradient-to-br from-gray-50 to-gray-100 flex-shrink-0">
                                  <img
                                    src={s.image || s.imgUrl || PLACEHOLDER_IMG}
                                    alt=""
                                    className="h-32 w-full object-cover transition-all duration-700 group-hover:scale-105"
                                  />
                                  
                                 
                                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                                  
                                 
                                  <button
                                    onClick={() => addFromCarousel(s)}
                                    className="absolute top-3 right-3 w-10 h-10 bg-white/90 backdrop-blur-sm hover:bg-white rounded-xl shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0 hover:scale-110 active:scale-95 border border-gray-200/50"
                                  >
                                    <FontAwesomeIcon icon={faPlus} className="text-yellow-600 text-sm" />
                                  </button>
                                  
                                 
                                  <div className="absolute bottom-3 left-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
                                    <div className="bg-white/90 backdrop-blur-sm rounded-lg px-2 py-1 shadow-md border border-gray-200/50">
                                      <span className="text-xs font-semibold text-gray-700">Add to board</span>
                                    </div>
                                  </div>
                                </div>
                                
                               
                                <div className="flex-1 flex flex-col justify-between space-y-3">
                                  <h3 className="font-bold text-gray-800 text-sm leading-tight group-hover:text-gray-900 transition-colors duration-200 line-clamp-2 flex-1">
                                    {s.title}
                                  </h3>
                                  
                                  <div className="flex items-center justify-between">
                                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200/60 rounded-xl px-3 py-1.5 shadow-sm">
                                      <p className="text-green-700 font-bold text-sm">
                                        {s.price}
                                      </p>
                                    </div>
                                    
                                    
                                    <div className="flex items-center gap-1">
                                      <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full"></div>
                                      <div className="w-1.5 h-1.5 bg-yellow-300 rounded-full"></div>
                                      <div className="w-1.5 h-1.5 bg-yellow-200 rounded-full"></div>
                                      <span className="text-xs text-gray-500 ml-1 font-medium">Match</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                          
                          
                          <div className="w-8 flex-shrink-0"></div>
                        </div>
                      </div>
                      
                     
                      <style jsx>{`
                        .horizontal-scroll-container {
                          -webkit-overflow-scrolling: touch;
                          scrollbar-width: thin;
                          scrollbar-color: #8B5CF6 #F3F4F6;
                        }
                        
                        .horizontal-scroll-container::-webkit-scrollbar {
                          height: 12px;
                          background: #F9FAFB;
                          border-radius: 6px;
                        }
                        
                        .horizontal-scroll-container::-webkit-scrollbar-track {
                          background: #F3F4F6;
                          border-radius: 6px;
                          border: 1px solid #E5E7EB;
                          margin: 0 8px;
                        }
                        
                        .horizontal-scroll-container::-webkit-scrollbar-thumb {
                          background: linear-gradient(90deg, #8B5CF6, #7C3AED);
                          border-radius: 6px;
                          border: 1px solid #F3F4F6;
                          min-width: 50px;
                          box-shadow: 0 2px 8px rgba(139, 92, 246, 0.3);
                        }
                        
                        .horizontal-scroll-container::-webkit-scrollbar-thumb:hover {
                          background: linear-gradient(90deg, #7C3AED, #6D28D9);
                          box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
                        }
                      `}</style>
                      
                      
                      <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-20">
                        <button 
                          className="w-10 h-10 bg-white/90 backdrop-blur-sm hover:bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200/60 hover:scale-110 active:scale-95"
                          onClick={(e) => {
                            const container = e.target.closest('.relative').querySelector('.horizontal-scroll-container');
                            container.scrollBy({ left: -300, behavior: 'smooth' });
                          }}
                        >
                          <svg className="w-4 h-4 text-gray-600 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                          </svg>
                        </button>
                      </div>
                      
                      <div className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20">
                        <button 
                          className="w-10 h-10 bg-white/90 backdrop-blur-sm hover:bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200/60 hover:scale-110 active:scale-95"
                          onClick={(e) => {
                            const container = e.target.closest('.relative').querySelector('.horizontal-scroll-container');
                            container.scrollBy({ left: 300, behavior: 'smooth' });
                          }}
                        >
                          <svg className="w-4 h-4 text-gray-600 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                          </svg>
                        </button>
                      </div>
                      
                      
                      <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex items-center gap-2 bg-white/80 backdrop-blur-sm rounded-full px-3 py-1.5 shadow-md border border-gray-200/60">
                        <div className="flex items-center gap-1">
                          {Array.from({ length: Math.min(5, Math.ceil(similarState.items.length / 3)) }, (_, i) => (
                            <div key={i} className="w-1.5 h-1.5 bg-gray-300 rounded-full"></div>
                          ))}
                        </div>
                        <span className="text-xs text-gray-500 font-medium ml-1">
                          {similarState.items.length} items
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        
        <WelcomeModal
          isOpen={isModalOpen}
          onClose={() => setModalOpen(false)}
          onSubmit={handleZipSubmit}
        />
        <SoftwareInstall 
          isOpen={installSoftwareModal}
          onClose={() => setInstallSoftwareModal(false)}
          onSubmit={handleZipSubmit} 
        />
      </div>
    </>
 
  );
}

/* === keep these helpers OUTSIDE the component (that’s fine) === */
const loadUserList  = () => JSON.parse(localStorage.getItem("userList") || "[]");
const saveUserList  = (l) => localStorage.setItem("userList", JSON.stringify(l));
