import React, { useState, useEffect } from "react";
import Hero from "../components/Hero";
import FeaturesSection from "../components/FeaturesSection";
import SearchBar from "../components/SearchBar";
import Navbar from "../components/Navbar";
import WelcomeModal from "../components/WelcomeModal";
import SoftwareInstall from "../components/SoftwareInstall";
import { useNavigate } from "react-router-dom";
import { motion } from 'framer-motion';
import { deepLinkUtils } from "../utils/deepLink";
import { scraperApi } from "../utils/api";

function LandingPage() {
  const [productName, setProductName] = useState("");
  const [scraping, setScraping] = useState(false);
  const [isModalOpen, setModalOpen] = useState(false); // Control modal visibility
  const [userZip, setUserZip] = useState(() => {
    // Load ZIP code from Local Storage
    return localStorage.getItem("userZip") || "";
  });
  const [softwareInstall, setSoftwareInstall] = useState(false);
  const [installSoftwareModal, setInstallSoftwareModal] = useState(false);
  const [locationDetected, setLocationDetected] = useState(false);
  const [autoLocation, setAutoLocation] = useState(null); // Store auto-detected location
  const navigate = useNavigate();

  // Check if REST server is running
  useEffect(() => {
    scraperApi.healthCheck()
      .then((isHealthy) => {
        if (isHealthy) setSoftwareInstall(true);
        else setSoftwareInstall(false);
      })
      .catch(() => setSoftwareInstall(false));
  }, []);

  // Auto-detect user location if available
  useEffect(() => {
    const autoDetectLocation = async () => {
      if (!userZip && softwareInstall) {
        try {
          const location = await deepLinkUtils.getUserLocation();
          if (location && location.zip) {
            setUserZip(location.zip);
            localStorage.setItem("userZip", location.zip);
            setLocationDetected(true);
            setAutoLocation(location); // Store the full location data
            console.log(`📍 Auto-detected location: ${location.city}, ${location.region} (${location.zip})`);
          }
        } catch (error) {
          console.warn('⚠️ Auto-location detection failed:', error);
        }
      }
    };

    if (softwareInstall) {
      autoDetectLocation();
    }
  }, [softwareInstall, userZip]);

  // Check for the software first, then location
  useEffect(() => {
    if (!softwareInstall) {
      setInstallSoftwareModal(true);
    } else if (!userZip && !locationDetected) {
      // Only show modal if location detection failed
      const timer = setTimeout(() => {
        if (!userZip) {
          setModalOpen(true);
        }
      }, 2000); // Give location detection 2 seconds to work
      
      return () => clearTimeout(timer);
    }
  }, [userZip, softwareInstall, locationDetected]);


  const scrapeFirstStores = () => {
    setScraping(true);
    setTimeout(() => setScraping(false), 2000); // Mock scraping function
  };

  const handleZipSubmit = (zip) => {
    setUserZip(zip); // Save ZIP to state
    localStorage.setItem("userZip", zip); // Save ZIP to Local Storage
    setModalOpen(false); // Close the modal
  };

  const openModal = () => {
    setModalOpen(true); // Allow manual opening of the modal
  };
  const navigateToMap = () => {
    navigate("/map");
  }

  return (
    <div className="flex">
      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <div className="flex-grow ml-20 min-h-screen bg-gray-100 text-gray-800 font-['Nunito']">
        {/* Hero Container */}
        <section className="relative w-full flex justify-center bg-white py-4 md:py-6">
          <div className="w-full max-w-6xl relative">
            <Hero />
            {/* Search Bar Positioned at the Bottom */}
            <div className="absolute bottom-4 left-0 right-0 flex items-center justify-center">
              <SearchBar
                productName={productName}
                setProductName={setProductName}
                scrapeFirstStores={scrapeFirstStores}
                scraping={scraping}
                openModal={openModal} // Allow SearchBar to open the modal
              />
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="w-full flex justify-center bg-gradient-to-b from-gray-50 to-white py-16 md:py-24">
        <div className="w-full max-w-7xl space-y-20 md:space-y-32">
          <FeaturesSection
            title="Intelligent Planning"
            description="Transform how you plan meals with effortless precision"
            bulletPoints={[
              "AI-powered meal suggestions that adapt to your preferences",
              "Seamlessly organize your week with smart scheduling",
              "Effortlessly maintain healthy habits that stick"
            ]}
            buttonText="Start Planning"
            buttonAction={() => navigateToMap()}
            imageSrc="https://images.unsplash.com/photo-1466637574441-749b8f19452f?w=800&h=600&fit=crop"
          />
          <FeaturesSection
            reversed
            title="Smart Shopping"
            description="Never miss a deal. Never exceed your budget."
            bulletPoints={[
              "Discover premium deals curated just for you",
              "Track spending with elegant, intuitive insights",
              "Stay perfectly within budget with intelligent alerts"
            ]}
            buttonText="Shop Smarter"
            buttonAction={() => navigateToMap()}
            imageSrc="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=600&fit=crop"
          />
        </div>
      </section>

        {/* Welcome Modal */}
        <WelcomeModal
          isOpen={isModalOpen}
          onClose={() => setModalOpen(false)}
          onSubmit={handleZipSubmit}
          autoLocation={autoLocation} // Pass auto-detected location
        />
        <SoftwareInstall 
          isOpen={installSoftwareModal}
          onClose={() => setInstallSoftwareModal(false)}
          onSubmit={handleZipSubmit} />
      </div>
    </div>
  );
}

export default LandingPage;
