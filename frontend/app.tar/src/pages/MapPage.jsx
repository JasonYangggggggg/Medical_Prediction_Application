import React, { useState, useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import SoftwareInstall from "../components/SoftwareInstall";
import WelcomeModal from "../components/WelcomeModal";
import { deepLinkUtils } from "../utils/deepLink";
import { scraperApi } from "../utils/api";

/* ───────────────────────── constants ───────────────────────── */
const POLL_MS = 800;
const POLL_TIMEOUT_MS = 35_000;
const PLACEHOLDER_IMG =
  "https://raw.githubusercontent.com/tailwindlabs/heroicons/074a8abd/optimized/outline/photo.svg";

/* Fix Leaflet’s default icon paths so markers load correctly */
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
  iconUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
  shadowUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
});

/* ──────────── reusable product-card ─────────── */

const ProductCard = ({ item, onClick, isSelected, onAdd, index }) => {
  const [justAdded, setJustAdded] = useState(false);
  const [imageError, setImageError] = useState(false);

  const handleAdd = (e) => {
    e.stopPropagation();
    setJustAdded(true);
    onAdd(item);
    setTimeout(() => setJustAdded(false), 600);
  };

  const handleImageError = () => {
    setImageError(true);
  };

  return (
    <div
      onClick={() => onClick?.(item)}
      className={`group relative bg-white/95 backdrop-blur-sm border border-gray-200/60 rounded-xl p-4 cursor-pointer
        transition-all duration-300 hover:shadow-xl hover:shadow-yellow-200/20 hover:scale-[1.02]
        ${isSelected ? "ring-2 ring-yellow-400 bg-yellow-50/90" : "hover:bg-white/98"}
        animate-fadeInUp`}
      style={{
        animationDelay: `${index * 100}ms`,
        animationFillMode: 'both'
      }}
    >
      {/* Add to list button */}
      <button
        onClick={handleAdd}
        title="Save to my list"
        className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center
          text-white text-sm font-bold transition-all duration-300 z-10
          ${justAdded 
            ? "bg-green-500 scale-110 shadow-lg" 
            : "bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-md hover:shadow-lg"
          }
          opacity-0 group-hover:opacity-100`}
      >
        {justAdded ? "✓" : "+"}
      </button>

      {/* Product Image */}
      <div className="w-full h-32 mb-3 rounded-lg overflow-hidden bg-gray-100">
        <img
          src={imageError ? PLACEHOLDER_IMG : (item.imgUrl || PLACEHOLDER_IMG)}
          alt={item.title || "Product"}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          onError={handleImageError}
        />
      </div>

      {/* Product Info */}
      <div className="space-y-2">
        <h3 className="font-semibold text-sm text-gray-900 line-clamp-2 leading-tight">
          {item.title || "No title available"}
        </h3>
        
        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-green-600">
            {item.price || "Price not available"}
          </span>
          <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
            {item.store || "Unknown store"}
          </span>
        </div>
      </div>

      {/* Selection indicator */}
      {isSelected && (
        <div className="absolute inset-0 pointer-events-none rounded-xl ring-2 ring-yellow-400 bg-yellow-400/5" />
      )}
    </div>
  );
};

const SimilarProductsSidebar = ({ 
  isOpen, 
  onClose, 
  products, 
  status, 
  selectedProductTitle,
  onAdd,
  similarCardClick,
  
}) => {
  if (!isOpen) return null;

  return (
  
    <div className="fixed right-0 top-0 h-full w-80 bg-white/95 backdrop-blur-md shadow-xl border-l border-gray-200/60 z-40 transform transition-transform duration-300">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200/60">
        <div>
          <h3 className="font-semibold text-gray-900">Similar Products</h3>
          {selectedProductTitle && (
            <p className="text-xs text-gray-500 mt-1 line-clamp-1">
              Similar to: {selectedProductTitle}
            </p>
          )}
        </div>
        <button
          onClick={onClose}
          className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
        >
          ✕
        </button>
      </div>

      {/* Content */}
      <div className="p-4 h-full overflow-y-auto pb-20">
        {status === "waiting" && (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin h-8 w-8 border-2 border-yellow-400 rounded-full border-t-transparent"></div>
            <span className="ml-3 text-sm text-gray-600">Finding similar products...</span>
          </div>
        )}

        {status === "error" && (
          <div className="text-center py-8">
            <p className="text-sm text-red-600">Error loading similar products</p>
            <button 
              onClick={onClose}
              className="mt-2 text-xs text-gray-500 hover:text-gray-700"
            >
              Close and try again
            </button>
          </div>
        )}

        {status === "done" && products.length === 0 && (
          <div className="text-center py-8">
            <p className="text-sm text-gray-500">No similar products found</p>
          </div>
        )}

        {status === "done" && products.length > 0 && (
          <div className="space-y-3">
            {products.map((product, index) => (
              <div
                key={index}
                onClick={() => similarCardClick?.(product)}
                className= "bg-white/80 rounded-lg p-3 border border-gray-200/60 hover:shadow-md transition-all duration-200"
              >
                <div className="flex gap-3">
                  <img
                    src={product.imgUrl || PLACEHOLDER_IMG}
                    alt={product.title}
                    className="w-16 h-16 object-cover rounded-md flex-shrink-0"
                    onError={(e) => (e.currentTarget.src = PLACEHOLDER_IMG)}
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm text-gray-900 line-clamp-2">
                      {product.title}
                    </h4>
                    <p className="text-green-600 font-semibold text-sm mt-1">
                      {product.price}
                    </p>
                    <p className="text-xs text-gray-500">{product.store}</p>
                  </div>
                  <button
                    onClick={() => onAdd?.(product)}
                    className="w-8 h-8 rounded-full bg-blue-500 hover:bg-blue-600 text-white flex items-center justify-center transition-colors"
                    title="Add to list"
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

/* ───────── helper: zoom map to fit all markers ───────── */
function FlyToBounds({ locations }) {
  const map = useMap();
  useEffect(() => {
    if (!locations.length) return;
    map.fitBounds(L.latLngBounds(locations.map((l) => [l.lat, l.lon])), {
      padding: [40, 40],
    });
  }, [locations, map]);
  return null;
}

// Red icon for user location
const userLocationIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Component to center map on user location
const CenterMapOnUser = ({ userLocation }) => {
  const map = useMap();
  
  useEffect(() => {
    if (userLocation && userLocation.lat && userLocation.lon) {
      map.setView([userLocation.lat, userLocation.lon], 12);
    }
  }, [userLocation, map]);
  
  return null;
};

/* ─────────────────────────── main component ───────────────────────── */
export default function ProductSearchPage() {
  /* ─── localStorage-backed state ─── */
  const [productName, setProductName] = useState(
    () => localStorage.getItem("lastQuery") || ""
  );
  const [status, setStatus] = useState(() =>
    localStorage.getItem("searchResults") ? "done" : "idle"
  );
  const [rawJson, setRawJson] = useState(() => {
    const saved = localStorage.getItem("searchResults");
    return saved ? JSON.parse(saved) : null;
  });
  const [showJson, setShowJson] = useState(false);
  const [locations, setLocations] = useState(() => {
    const saved = localStorage.getItem("mapLocations");
    return saved ? JSON.parse(saved) : [];
  });
  const [selectedItem, setSelectedItem] = useState(() => {
    const saved = localStorage.getItem("selectedItem");
    return saved ? JSON.parse(saved) : null;
  });
  const [comparisonItems, setComparisonItems] = useState(() => {
    const saved = localStorage.getItem("comparisonItems");
    return saved ? JSON.parse(saved) : [];
  });
  const [comparisonStatus, setComparisonStatus] = useState("idle");
  const [userList, setUserList] = useState(() => {
    const saved = localStorage.getItem("userList");
    return saved ? JSON.parse(saved) : [];
  });
  const [toast, setToast] = useState(null);

  /* map overlay state */
  const [mapMaximized, setMapMaximized] = useState(false);
  const [dragPos, setDragPos] = useState({ x: 0, y: 0 }); // NEW

  /* leaflet map ref to invalidate size on resize / toggle */
  const mapRef = useRef(null);
  const inputRef = useRef(null);
  const [softwareInstall, setSoftwareInstall] = useState(false);
  const [installSoftwareModal, setInstallSoftwareModal] = useState(false);
  const [scraping, setScraping] = useState(false);
  const [isModalOpen, setModalOpen] = useState(false); // Control modal visibility
  const [showSimilarProducts, setShowSimilarProducts] = useState(false);
  const [hasSimilarProductsData, setHasSimilarProductsData] = useState(false);
  const [userZip, setUserZip] = useState(() => {
    // Load ZIP code from Local Storage
    return localStorage.getItem("userZip") || "";
  });
  const [userAddress, setUserAddress] = useState(""); // State for user-entered address
  const [mapCenter, setMapCenter] = useState([45.5017, -73.5673]); // Default to Montreal center
  const [userLocation, setUserLocation] = useState(null); // Store detected user location
  
  /* ─── Auto-detect user location on mount ─── */
  useEffect(() => {
    const autoDetectLocation = async () => {
      try {
        const location = await deepLinkUtils.getUserLocation();
        
        if (location && location.lat && location.lon) {
          setUserLocation(location);
          setMapCenter([location.lat, location.lon]);
          
          // Also set ZIP and city for better search results
          if (location.zip) {
            setUserZip(location.zip);
            localStorage.setItem("userZip", location.zip);
          }
          
          console.log(`📍 Map centered on: ${location.city}, ${location.region}`);
        }
      } catch (error) {
        console.warn('⚠️ Auto-location detection failed:', error);
      }
    };
    
    // Only auto-detect if we don't have a ZIP code already, or always for debugging
    autoDetectLocation(); // Always try to detect location for now
  }, []); // Remove userZip dependency for debugging
  /* ─── sync to localStorage ─── */
  useEffect(() => {
    if (rawJson) localStorage.setItem("searchResults", JSON.stringify(rawJson));
  }, [rawJson]);
  useEffect(() => {
    localStorage.setItem("mapLocations", JSON.stringify(locations));
  }, [locations]);
  useEffect(() => {
    if (selectedItem)
      localStorage.setItem("selectedItem", JSON.stringify(selectedItem));
  }, [selectedItem]);
  useEffect(() => {
    localStorage.setItem("comparisonItems", JSON.stringify(comparisonItems));
  }, [comparisonItems]);
  useEffect(() => {
    localStorage.setItem("lastQuery", productName);
  }, [productName]);
  useEffect(() => {
    localStorage.setItem("userList", JSON.stringify(userList));
  }, [userList]);

  /* autofocus on mount */
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  /* handle map size changes */
  useEffect(() => {
    if (mapRef.current) mapRef.current.invalidateSize();
  }, [mapMaximized]);

  useEffect(() => {
    if (!mapMaximized) return;
    const onResize = () => {
      if (mapRef.current) mapRef.current.invalidateSize();
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [mapMaximized]);
   useEffect(() => {
        if(!softwareInstall){
            setInstallSoftwareModal(true);
        }
        
        
        else if (!userZip) {
          setModalOpen(true); // Show modal if no ZIP code is set
        }
      }, [userZip, softwareInstall]);

const [filterStore, setFilterStore] = useState('');
const [sortBy, setSortBy] = useState('none'); // 'none', 'price-asc', 'price-desc'

// Add this helper function to extract numeric price from price string
const extractPrice = (priceStr) => {
  if (!priceStr) return 0;
  const numStr = priceStr.replace(/[^0-9.,]/g, '').replace(',', '.');
  const num = parseFloat(numStr);
  return isNaN(num) ? 0 : num;
};

// Add this helper function to get unique store names
const getUniqueStores = (items) => {
  if (!items || items.length === 0) return [];
  const stores = items.map(item => item.store).filter(store => store);
  return [...new Set(stores)].sort();
};

// Add this helper function to filter and sort products
const getFilteredAndSortedProducts = (items) => {
  if (!items || items.length === 0) return [];
  
  // Filter by store
  let filtered = items;
  if (filterStore && filterStore !== 'all') {
    filtered = items.filter(item => 
      item.store && item.store.toLowerCase().includes(filterStore.toLowerCase())
    );
  }
  
  // Sort by price
  if (sortBy === 'price-asc') {
    filtered = [...filtered].sort((a, b) => extractPrice(a.price) - extractPrice(b.price));
  } else if (sortBy === 'price-desc') {
    filtered = [...filtered].sort((a, b) => extractPrice(b.price) - extractPrice(a.price));
  }
  
  return filtered;
};

const handleZipSubmit = (zip) => {
    setUserZip(zip); // Save ZIP to state
    localStorage.setItem("userZip", zip); // Save ZIP to Local Storage
    setModalOpen(false); // Close the modal
  };

  const openModal = () => {
    setModalOpen(true); // Allow manual opening of the modal
  };

  const handleAddressSubmit = async () => {
    if (!userAddress.trim()) return alert("Please enter a valid address.");

    try {
      const data = await scraperApi.getMap(userAddress);
      if (data.results && data.results[0]?.coordinates) {
        const { latitude, longitude } = data.results[0].coordinates;
        setMapCenter([latitude, longitude]);
      } else {
        alert("Could not find location for the entered address.");
      }
    } catch (error) {
      console.error("Error fetching location:", error);
      alert("Failed to fetch location. Please try again.");
    }
  };

  /* helper: maximise/minimise & snap back */
  const toggleMaximise = () => {
    if (!mapMaximized) {
      setDragPos({ x: 0, y: 0 }); // snap back before maximising
    }
    setMapMaximized(!mapMaximized);
  };

  /* ─── add product to list (toast) ─── */
  const addToUserList = async (product) => {
  // If we already looked this store up in the current session, reuse it
  const storeName = product.store || "";
  let locs = storeName ? getCachedMapResult(storeName) : null;

  // Otherwise hit the DDG Maps endpoint (via your local proxy)
  if (!locs && storeName) {
    try {
      const json = await scraperApi.getMap(`${storeName} near ${userZip || "me"}`);

      locs =
        (json.results || [])
          .filter(
            (pl) => pl.coordinates?.latitude && pl.coordinates?.longitude
          )
          .map((pl) => ({
            name: pl.name || storeName,
            lat: +pl.coordinates.latitude,
            lon: +pl.coordinates.longitude,
          })) || [];

      setCachedMapResult(storeName, locs); // save for next click
    } catch (err) {
      console.error("Map lookup failed:", err);
      locs = [];         // graceful fallback
    }
  }

  // Attach the geo data (empty array if we failed, but still proceed)
  product.location = locs || [];

  /* === Add product to user list regardless of location data === */
  const updated = [...userList, product];
  setUserList(updated);

  // Also update kanbanColumns in localStorage
  const kanbanColumns = JSON.parse(localStorage.getItem("kanbanColumns") || "{}");
  if (kanbanColumns) {
    const colId = Object.keys(kanbanColumns)[0];
    if (colId && kanbanColumns[colId]) {
      kanbanColumns[colId].items.push(product);
      localStorage.setItem("kanbanColumns", JSON.stringify(kanbanColumns));
    }
  }

  // Show success toast
  setToast(`${product.title?.slice(0, 40) || "Item"} added!`);
  setTimeout(() => setToast(null), 2000);
};

  /* ─── launch scraper + poll with deep-link ─── */
  const launchScraperAndPoll = async () => {
    const trimmed = productName.trim();
    if (!trimmed) return alert("Enter a product first.");

    setStatus("waiting");
    setRawJson(null);
    setLocations([]);

    try {
      console.log('🚀 Starting deep-link scraper...');
      
      // Try deep-link first
      const result = await deepLinkUtils.launchScraper(trimmed);
      
      console.log('🔍 Deep-link result analysis:', {
        hasResult: !!result,
        hasItems: !!(result && result.items),
        itemsLength: result?.items?.length,
        itemsType: typeof result?.items,
        fullResult: result
      });

      if (result && result.items && result.items.length > 0) {
        console.log('✅ Deep-link succeeded, setting results to state');
        setRawJson(result);
        setStatus("done");
        return; // IMPORTANT: Don't continue to fallback
      } else {
        console.log('❌ Deep-link failed or no results, trying fallback');
        console.log('❌ Condition failed because:', {
          result: !!result,
          items: !!(result && result.items),
          length: result?.items?.length > 0
        });
      }
    } catch (error) {
      console.error("Deep-link failed:", error);
    }
    
    // Only run fallback if deep-link failed
    console.log('🔄 Running fallback API scrape...');
    await fallbackApiScrape(trimmed);
  };

  /* ─── fallback API scrape (if deep-link fails) ─── */
  const fallbackApiScrape = async (query) => {
    try {
      // Trigger the scraping
      await scraperApi.scrapeDeals(query);
      
      // Poll for results from results.json
      const started = Date.now();
      (function poll() {
        scraperApi.getResults()
          .then((data) => {
            console.log('🔍 Polling data received:', {
              query: data?.query,
              originalQuery: data?.originalQuery,
              searchQuery: query,
              itemCount: data?.items?.length
            });
            
            // Check both query and originalQuery for matches
            const queryMatch = data && (
              data.query?.toLowerCase().includes(query.toLowerCase()) ||
              data.originalQuery?.toLowerCase().includes(query.toLowerCase()) ||
              query.toLowerCase().includes(data.query?.toLowerCase()) ||
              query.toLowerCase().includes(data.originalQuery?.toLowerCase())
            );
            
            if (queryMatch && data.items && data.items.length > 0) {
              console.log('✅ Query match found, setting results');
              setRawJson(data);
              setStatus("done");
              return;
            }
            
            if (Date.now() - started < POLL_TIMEOUT_MS) {
              setTimeout(poll, POLL_MS);
            } else {
              console.log('❌ Polling timeout reached');
              setStatus("error");
            }
          })
          .catch((error) => {
            console.log("Poll error:", error);
            if (Date.now() - started < POLL_TIMEOUT_MS) {
              setTimeout(poll, POLL_MS);
            } else {
              setStatus("error");
            }
          });
      })();
    } catch (error) {
      console.error("Fallback API scrape failed:", error);
      setStatus("error");
    }
  };

  /* ─── scrape comparison items ─── */
  const scrapeComparisonProducts = async (query) => {
    setComparisonStatus("waiting");
    setComparisonItems([]);

    try {
      // Trigger the scraping
      await scraperApi.scrapeDeals(query);
      
      // Poll for results from results.json
      const started = Date.now();
      (function poll() {
        scraperApi.getResults()
          .then((data) => {
            console.log('🔍 Comparison polling data received:', {
              query: data?.query,
              originalQuery: data?.originalQuery,
              searchQuery: query,
              itemCount: data?.items?.length
            });
            
            // Check both query and originalQuery for matches
            const queryMatch = data && (
              data.query?.toLowerCase().includes(query.toLowerCase()) ||
              data.originalQuery?.toLowerCase().includes(query.toLowerCase()) ||
              query.toLowerCase().includes(data.query?.toLowerCase()) ||
              query.toLowerCase().includes(data.originalQuery?.toLowerCase())
            );
            
            if (queryMatch && data.items && data.items.length > 0) {
              console.log('✅ Comparison query match found, setting results');
              setComparisonItems(data.items);
              setComparisonStatus("done");
              return;
            }
            
            if (Date.now() - started < POLL_TIMEOUT_MS) {
              setTimeout(poll, POLL_MS);
            } else {
              console.log('❌ Comparison polling timeout reached');
              setComparisonStatus("error");
            }
          })
          .catch((error) => {
            console.log("Comparison poll error:", error);
            if (Date.now() - started < POLL_TIMEOUT_MS) {
              setTimeout(poll, POLL_MS);
            } else {
              setComparisonStatus("error");
            }
          });
      })();
    } catch (error) {
      console.error("Comparison scrape failed:", error);
      setComparisonStatus("error");
    }
  };

  /* ─── card click: map lookup + comparison scrape ─── */
  const handleCardClick = (item) => {
    setSelectedItem(item);
    setLocations([]);

    const storeName = item.store || "";
    if (storeName) {
      const cached = getCachedMapResult(storeName);
      if (cached) {
        setLocations(cached);
        setShowSimilarProducts(true);
        setHasSimilarProductsData(true);
      } else {
        scraperApi.getMap(`${storeName} near me`)
          .then((json) => {
            const locs =
              (json.results || [])
                .filter(
                  (pl) => pl.coordinates?.latitude && pl.coordinates?.longitude
                )
                .map((pl) => ({
                  name: pl.name || storeName,
                  lat: +pl.coordinates.latitude,
                  lon: +pl.coordinates.longitude,
                })) || [];
            setLocations(locs);
            setCachedMapResult(storeName, locs);
            setShowSimilarProducts(true);
            setHasSimilarProductsData(true);
          })
          .catch((err) => console.error("Map lookup failed:", err));
      }
    }

    if (item.title) scrapeComparisonProducts(item.title);
  };
  const handleCardClickSimilarProduct = (item) => {
    setSelectedItem(item);
    setLocations([]);

    const storeName = item.store || "";
    if (storeName) {
      const cached = getCachedMapResult(storeName);
      if (cached) {
        setLocations(cached);
      } else {
        scraperApi.getMap(`${storeName} near me`)
          .then((json) => {
            const locs =
              (json.results || [])
                .filter(
                  (pl) => pl.coordinates?.latitude && pl.coordinates?.longitude
                )
                .map((pl) => ({
                  name: pl.name || storeName,
                  lat: +pl.coordinates.latitude,
                  lon: +pl.coordinates.longitude,
                })) || [];
            setLocations(locs);
            setCachedMapResult(storeName, locs);
          })
          .catch((err) => console.error("Map lookup failed:", err));
      }
    }

  
  };
  
    const closeSimilarProducts = () => {
    setShowSimilarProducts(false);
  };

  const reopenSimilarProducts = () => {
    setShowSimilarProducts(true);
  };

  /* ───────────────────────── UI ───────────────────────── */

return (
  <div className="relative h-screen overflow-hidden bg-gray-100">
    
    {toast && (
      <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-green-600 text-white px-6 py-3 rounded-full shadow-lg animate-fadeInDown z-[10001]">
        {toast}
      </div>
    )}

    
    <div className="absolute inset-0 z-0">
      <MapContainer
        center={mapCenter} // Use dynamic map center
        zoom={12}
        className="w-full h-full"
        zoomControl={false}
        attributionControl={false}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
          attribution="© OpenStreetMap contributors, © CARTO"
        />
        
        {/* User Location Marker */}
        {userLocation && userLocation.lat && userLocation.lon && (
          <Marker 
            position={[userLocation.lat, userLocation.lon]}
            icon={userLocationIcon}
          >
            <Popup className="custom-popup">
              <div className="p-3 min-w-[200px]">
                <h4 className="font-semibold text-sm mb-2">📍 Your Location</h4>
                <p className="text-xs text-gray-600 mb-1">
                  {userLocation.city}, {userLocation.region}
                </p>
                {userLocation.zip && (
                  <p className="text-xs text-gray-500 mb-3">ZIP: {userLocation.zip}</p>
                )}
                <button
                  onClick={() => {
                    const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${userLocation.lat},${userLocation.lon}`;
                    window.open(googleMapsUrl, '_blank');
                  }}
                  className="w-full bg-red-500 hover:bg-red-600 text-white text-xs font-medium py-2 px-3 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
                >
                  <svg 
                    width="14" 
                    height="14" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path 
                      d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" 
                      fill="currentColor"
                    />
                  </svg>
                  Get Directions to Your Location
                </button>
              </div>
            </Popup>
          </Marker>
        )}
       
        {/* Store Location Markers */}
        {locations.map((loc, idx) => (
            <Marker key={idx} position={[loc.lat, loc.lon]}>
              <Popup className="custom-popup">
                <div className="p-3 min-w-[200px]">
                  <h4 className="font-semibold text-sm mb-2">{loc.name}</h4>
                  <p className="text-xs text-gray-600 mb-3">📍 Store location</p>
                  
                  <button
                    onClick={() => {
                      const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${loc.lat},${loc.lon}`;
                      window.open(googleMapsUrl, '_blank');
                    }}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white text-xs font-medium py-2 px-3 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
                  >
                    <svg 
                      width="14" 
                      height="14" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path 
                        d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" 
                        fill="currentColor"
                      />
                    </svg>
                     Get Directions in Google Maps
                  </button>
                </div>
              </Popup>
            </Marker>
          ))}
        
        {/* Center map on user location */}
        <CenterMapOnUser userLocation={userLocation} />
        
        {locations.length > 0 && <FlyToBounds locations={locations} />}
      </MapContainer>
    </div>

    
    <div className="relative z-10 w-96 h-full bg-white/90 backdrop-blur-md shadow-xl border-r border-gray-200/60 ml-20">
      
      <div className="p-6 border-b border-gray-200/60 bg-white/95">
        <h1 className="text-2xl font-light text-gray-900 mb-4">Product Search</h1>

        <div className="space-y-3">
          <div className="relative">
            <input
              ref={inputRef}
              className="w-full px-4 py-3 text-sm bg-gray-50/80 border border-gray-200/60 rounded-xl outline-none transition-all duration-200 focus:bg-white focus:border-yellow-400 focus:ring-4 focus:ring-yellow-100 placeholder-gray-500"
              type="text"
              placeholder="Search for products..."
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && launchScraperAndPoll()}
            />
            {productName && (
              <button
                onClick={() => setProductName('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 w-6 h-6 flex items-center justify-center rounded-full bg-gray-300 hover:bg-gray-400 transition-colors"
              >
                <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
            )}
          </div>
          
          {/* COMMENTED OUT - Address input and Set Location button
          <div className="relative">
            <input
              className="w-full px-4 py-3 text-sm bg-gray-50/80 border border-gray-200/60 rounded-xl outline-none transition-all duration-200 focus:bg-white focus:border-blue-400 focus:ring-4 focus:ring-blue-100 placeholder-gray-500"
              type="text"
              placeholder="Enter your address..."
              value={userAddress}
              onChange={(e) => setUserAddress(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddressSubmit()}
            />
          </div>

          <button
            onClick={handleAddressSubmit}
            className="w-full px-6 py-3 bg-gradient-to-r from-blue-400 to-blue-500 hover:from-blue-500 hover:to-blue-600 text-white font-medium text-sm rounded-xl transition-all duration-200 shadow-lg hover:shadow-blue-200/50 focus:ring-4 focus:ring-blue-100 active:scale-95"
          >
            Set Location
          </button>
          */}

          <button
            onClick={launchScraperAndPoll}
            disabled={status === "waiting" || !productName.trim()}
            className="w-full px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-white font-medium text-sm rounded-xl transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed shadow-lg hover:shadow-yellow-200/50 focus:ring-4 focus:ring-yellow-100 active:scale-95"
          >
            {status === "waiting" ? (
              <div className="flex items-center justify-center gap-2">
                <svg
                  className="animate-spin w-4 h-4"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 0114 0 7.962 7.962 0 01-2.291 5.291A7.962 7.962 0 0112 20a8 8 0 01-8-8h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
                Searching...
              </div>
            ) : (
              "Search Products"
            )}
          </button>
        </div>
      </div>

      
      <div className="flex-1 overflow-y-auto p-4 space-y-4 h-[calc(100vh-200px)]">
        {status === "idle" && (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-200 rounded-full flex items-center justify-center">
              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <p className="text-gray-500 text-sm">Enter a product name and search to get started</p>
          </div>
        )}

        {status === "waiting" && (
          <div className="text-center py-12">
            <div className="animate-spin h-8 w-8 border-2 border-yellow-400 rounded-full border-t-transparent mx-auto mb-4"></div>
            <p className="text-yellow-600 text-sm">Searching for products...</p>
          </div>
        )}

        {status === "error" && (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center">
              <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="text-red-600 text-sm">Error occurred while searching</p>
          </div>
        )}

        {status === "done" && rawJson?.items?.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-200 rounded-full flex items-center justify-center">
              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
            </div>
            <p className="text-gray-500 text-sm">No products found for your search</p>
          </div>
        )}

        {status === "done" && rawJson?.items?.length > 0 && (() => {
          const filteredAndSortedProducts = getFilteredAndSortedProducts(rawJson.items);
          const uniqueStores = getUniqueStores(rawJson.items);
          
          return (
            <div className="space-y-4">
             
              <div className="bg-white/98 backdrop-blur-xl border border-gray-100 rounded-3xl p-6 space-y-6 shadow-[0_4px_20px_rgba(0,0,0,0.04)]">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h2 className="text-xl font-light text-gray-900">
                      {rawJson.items.length} {rawJson.items.length === 1 ? 'product' : 'products'}
                    </h2>
                    {filteredAndSortedProducts.length !== rawJson.items.length && (
                      <p className="text-sm text-gray-500 font-light">
                        {filteredAndSortedProducts.length} shown
                      </p>
                    )}
                  </div>
                  <div className="text-xs text-gray-400 bg-gray-50 px-3 py-1.5 rounded-full border border-gray-100 font-medium">
                    Tap to compare
                  </div>
                </div>
                
                <div className="space-y-5">
                 
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-gray-600 block">
                      Store
                    </label>
                    <div className="relative">
                      <select
                        value={filterStore}
                        onChange={(e) => setFilterStore(e.target.value)}
                        className="w-full px-4 py-3.5 text-sm bg-gray-50/50 border-0 rounded-2xl outline-none transition-all duration-300 focus:bg-white focus:shadow-[0_0_0_1px_#3b82f6] focus:shadow-blue-100/50 appearance-none cursor-pointer hover:bg-white/80"
                      >
                        <option value="">All stores</option>
                        {uniqueStores.map(store => (
                          <option key={store} value={store}>{store}</option>
                        ))}
                      </select>
                      <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none">
                        <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9" />
                        </svg>
                      </div>
                    </div>
                  </div>
                  
                  
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-gray-600 block">
                      Sort by price
                    </label>
                    <div className="relative">
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="w-full px-4 py-3.5 text-sm bg-gray-50/50 border-0 rounded-2xl outline-none transition-all duration-300 focus:bg-white focus:shadow-[0_0_0_1px_#3b82f6] focus:shadow-blue-100/50 appearance-none cursor-pointer hover:bg-white/80"
                      >
                        <option value="none">Default</option>
                        <option value="price-asc">Low to high</option>
                        <option value="price-desc">High to low</option>
                      </select>
                      <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none">
                        <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                
            
                {(filterStore || sortBy !== 'none') && (
                  <button
                    onClick={() => {
                      setFilterStore('');
                      setSortBy('none');
                    }}
                    className="w-full px-4 py-3 text-sm font-medium text-gray-500 hover:text-gray-700 bg-gray-50/50 hover:bg-gray-100/70 border-0 rounded-2xl transition-all duration-300 flex items-center justify-center gap-2 hover:shadow-sm active:scale-[0.98]"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
                    </svg>
                    Reset filters
                  </button>
                )}
              </div>

              
              {filteredAndSortedProducts.length === 0 ? (
                <div className="text-center py-8">
                  <div className="w-12 h-12 mx-auto mb-3 bg-gray-200 rounded-full flex items-center justify-center">
                    <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                    </svg>
                  </div>
                  <p className="text-gray-500 text-sm">No products match your current filters</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredAndSortedProducts.map((item, i) => (
                    <ProductCard
                      key={`${item.store}-${item.title}-${i}`}
                      item={item}
                      onClick={handleCardClick}
                      onAdd={addToUserList}
                      isSelected={selectedItem?.store === item.store && selectedItem?.title === item.title}
                      index={i}
                    />
                  ))}
                </div>
              )}
            </div>
          );
        })()}
      </div>
    </div>
    
    {!showSimilarProducts && (
      <div className="fixed top-1/2 right-6 -translate-y-1/2 z-20">
        <button
          onClick={reopenSimilarProducts}
          className="group relative bg-white/80 backdrop-blur-xl border border-black/5 rounded-3xl px-6 py-4 shadow-[0_8px_32px_rgba(0,0,0,0.06)] hover:shadow-[0_20px_60px_rgba(0,0,0,0.12)] hover:bg-white/90 transition-all duration-500 ease-out hover:-translate-y-1 active:scale-95 active:transition-transform active:duration-75"
          title="Open Comparison Panel"
        >
         
          <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          
          <div className="relative flex flex-col items-center gap-3">
            <div className="relative">
              
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100/50 flex items-center justify-center group-hover:from-blue-50 group-hover:to-indigo-50/50 transition-all duration-300">
                <svg 
                  className="w-5 h-5 text-slate-600 group-hover:text-blue-600 transition-colors duration-300" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z" 
                  />
                </svg>
              </div>
              
            
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full shadow-sm group-hover:shadow-blue-200 transition-shadow duration-300">
                <div className="absolute inset-0 rounded-full bg-blue-400 animate-ping opacity-30"></div>
              </div>
            </div>
            
            <span className="text-sm font-medium text-slate-700 group-hover:text-slate-900 transition-colors duration-300 tracking-[-0.01em]">
              Compare
            </span>
          </div>
        </button>
      </div>
    )}

  
    <SimilarProductsSidebar
      isOpen={showSimilarProducts}
      onClose={closeSimilarProducts}
      products={comparisonItems}
      status={comparisonStatus}
      selectedProductTitle={selectedItem?.title}
      onAdd={addToUserList}
      similarCardClick={handleCardClickSimilarProduct}
    />
    
    <WelcomeModal
      isOpen={isModalOpen}
      onClose={() => setModalOpen(false)}
      onSubmit={handleZipSubmit}
    />
    
    <SoftwareInstall 
      isOpen={installSoftwareModal}
      onClose={() => setInstallSoftwareModal(false)}
      onSubmit={handleZipSubmit} 
    />

    
    <style jsx>{`
      @keyframes fadeInUp {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
      
      @keyframes fadeInDown {
        from {
          opacity: 0;
          transform: translateY(-20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
      
      .animate-fadeInUp {
        animation: fadeInUp 0.6s ease-out;
      }
      
      .animate-fadeInDown {
        animation: fadeInDown 0.3s ease-out;
      }
      
      .line-clamp-1 {
        display: -webkit-box;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }
      
      .line-clamp-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }
      
      .leaflet-popup-content-wrapper {
        border-radius: 8px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      }
    `}</style>
  </div>
);
}

/* ───────── Tailwind CSS (add to globals) ─────────
@layer utilities {
  @keyframes slidefade {
    from { opacity:0; transform:translate(-50%, -1rem); }
    to   { opacity:1; transform:translate(-50%, 0); }
  }
  .animate-slidefade { animation: slidefade 0.3s ease-out; }
}
*/

/* ───────── Notes ─────────
1. `npm install react-draggable`
2. Map overlay is bounded to the viewport (`bounds="parent"`). Drag position is
   stored in state; when you maximise the map, the drag offset resets so that
   minimising returns it to its original top-right spawn location.
*/

// Map location cache helpers
function getCachedMapResult(storeName) {
  try {
    const cache = JSON.parse(localStorage.getItem("mapCache") || "{}");
    return cache[storeName] || null;
  } catch {
    return null;
  }
}

function setCachedMapResult(storeName, result) {
  try {
    const cache = JSON.parse(localStorage.getItem("mapCache") || "{}");
    cache[storeName] = result;
    localStorage.setItem("mapCache", JSON.stringify(cache));
  } catch {}
}

/* ─────────────────────────── main component (with map) ───────────────────────── */
export function MapPage() {
  const [userLocation, setUserLocation] = useState(null);
  const [softwareInstall, setSoftwareInstall] = useState(false);
  const [installSoftwareModal, setInstallSoftwareModal] = useState(false);
  const [userZip, setUserZip] = useState(() => localStorage.getItem("userZip") || "");
  const [mapCenter, setMapCenter] = useState([39.8283, -98.5795]); // Default to USA center

  /* ─── Auto-detect user location when software is available ─── */
  useEffect(() => {
    if (softwareInstall) {
      scraperApi.getLocation()
        .then(data => {
          if (data && data.lat && data.lon) {
            setUserLocation(data);
            setMapCenter([data.lat, data.lon]);
            setUserZip(data.zip || "");
            console.log("Auto-detected location:", data);
          }
        })
        .catch(err => {
          console.log("Could not auto-detect location:", err);
          // Fallback to deep-link location detection
          if (window.deepLink) {
            window.deepLink.getLocation().then(loc => {
              if (loc && loc.lat && loc.lon) {
                setUserLocation(loc);
                setUserZip(loc.zip || "");
              }
            });
          }
        });
    }
  }, [softwareInstall]);

  /* helper: maximise/minimise & snap back */
  const toggleMaximise = () => {
    setMapMaximized(!mapMaximized);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50">
      {/* ...existing header code... */}

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* ...existing search and controls... */}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Results Panel */}
          <div className="space-y-6">
            {/* ...existing results code... */}
          </div>

          {/* Map Panel */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h2 className="text-xl font-bold mb-4 text-gray-800">
              📍 Store Locations
              {userLocation && (
                <span className="text-sm font-normal text-gray-600 ml-2">
                  📍 {userLocation.city}, {userLocation.region}
                </span>
              )}
            </h2>
            
            <div className="h-96 rounded-lg overflow-hidden border-2 border-gray-200">
              <MapContainer
                center={userLocation ? [userLocation.lat, userLocation.lon] : [39.8283, -98.5795]}
                zoom={userLocation ? 12 : 4}
                style={{ height: "100%", width: "100%" }}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                
                {/* Map Controller */}
                <MapController userLocation={userLocation} locations={locations} />
                
                {/* User Location Marker */}
                {userLocation && userLocation.lat && userLocation.lon && (
                  <Marker 
                    position={[userLocation.lat, userLocation.lon]}
                    icon={userLocationIcon}
                  >
                    <Popup>
                      <div className="text-center">
                        <h3 className="font-bold text-blue-600">📍 Your Location</h3>
                        <p className="text-sm text-gray-600">
                          {userLocation.city}, {userLocation.region}
                        </p>
                        <p className="text-xs text-gray-500">
                          {userLocation.zip && `ZIP: ${userLocation.zip}`}
                        </p>
                      </div>
                    </Popup>
                  </Marker>
                )}

                {/* Store Location Markers */}
                {locations.map((loc, idx) => (
                  <Marker key={idx} position={[loc.lat, loc.lon]}>
                    <Popup>
                      <div className="text-center">
                        <h3 className="font-bold text-orange-600">🏪 {loc.name}</h3>
                        <p className="text-sm text-gray-600">Store Location</p>
                        {loc.address && (
                          <p className="text-xs text-gray-500 mt-1">{loc.address}</p>
                        )}
                      </div>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            </div>

            {/* Location Info Panel */}
            {userLocation && (
              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold text-blue-800 mb-2">
                  📍 Detected Location
                </h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-600">City:</span>
                    <span className="ml-2 font-medium">{userLocation.city}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">State:</span>
                    <span className="ml-2 font-medium">{userLocation.region}</span>
                  </div>
                  {userLocation.zip && (
                    <div>
                      <span className="text-gray-600">ZIP:</span>
                      <span className="ml-2 font-medium">{userLocation.zip}</span>
                    </div>
                  )}
                  <div>
                    <span className="text-gray-600">Country:</span>
                    <span className="ml-2 font-medium">{userLocation.country}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Map Legend */}
            <div className="mt-4 flex justify-center space-x-6 text-sm text-gray-600">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-blue-500 rounded-full mr-2"></div>
                <span>Your Location</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-orange-500 rounded-full mr-2"></div>
                <span>Store Locations</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ───────── Tailwind CSS (add to globals) ─────────
@layer utilities {
  @keyframes slidefade {
    from { opacity:0; transform:translate(-50%, -1rem); }
    to   { opacity:1; transform:translate(-50%, 0); }
  }
  .animate-slidefade { animation: slidefade 0.3s ease-out; }
}
*/

/* ───────── Notes ─────────
1. `npm install react-draggable`
2. Map overlay is bounded to the viewport (`bounds="parent"`). Drag position is
   stored in state; when you maximise the map, the drag offset resets so that
   minimising returns it to its original top-right spawn location.
*/

/* ─────────────────────────── helper components ───────────────────────── */

// Component to handle map centering and user location
const MapController = ({ userLocation, locations }) => {
  const map = useMap();
  
  useEffect(() => {
    if (userLocation && userLocation.lat && userLocation.lon) {
      // Center map on user location
      map.setView([userLocation.lat, userLocation.lon], 12);
    }
  }, [userLocation, map]);

  // Auto-fit bounds when locations are added
  useEffect(() => {
    if (locations.length > 0) {
      const allPoints = [...locations];
      if (userLocation && userLocation.lat && userLocation.lon) {
        allPoints.push({ lat: userLocation.lat, lon: userLocation.lon });
      }
      
      if (allPoints.length > 1) {
        const bounds = L.latLngBounds(allPoints.map(loc => [loc.lat, loc.lon]));
        map.fitBounds(bounds, { padding: [20, 20] });
      }
    }
  }, [locations, userLocation, map]);

  return null;
};
