// import React, { useState } from "react";

// const TokenVerificationPage = ({ onVerified }) => {
//   const [token, setToken] = useState("");
//   const [error, setError] = useState("");
//   const [loading, setLoading] = useState(false);

//   const handleVerify = async () => {
//     setError("");
//     setLoading(true);

//     try {
//       const response = await fetch("http://127.0.0.1:8000/api/auth/verify", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ token }),
//       });

//       if (response.ok) {
//         onVerified(); // Navigate back to login after verification
//       } else {
//         const errorData = await response.json();
//         setError(errorData.detail || "Verification failed.");
//       }
//     } catch (error) {
//       setError("An error occurred. Please try again.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
//       <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
//         <h2 className="text-2xl font-bold mb-4 text-center">Verify Your Account</h2>
//         {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
//         <div className="mb-4">
//           <input
//             type="text"
//             value={token}
//             onChange={(e) => setToken(e.target.value)}
//             placeholder="Enter Verification Token"
//             className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-yellow-500"
//           />
//         </div>
//         <button
//           onClick={handleVerify}
//           disabled={loading}
//           className={`w-full py-2 rounded-lg ${
//             loading
//               ? "bg-gray-400 cursor-not-allowed"
//               : "bg-black hover:bg-gray-800 text-white"
//           }`}
//         >
//           {loading ? "Verifying..." : "Verify"}
//         </button>
//       </div>
//     </div>
//   );
// };

// export default TokenVerificationPage;
